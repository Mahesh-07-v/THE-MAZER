import pygame
import os
from monster import Monster

class Spider(Monster):
    def __init__(self, x, y, speed, maze, detection_radius=130, patrol_route=None):
        super().__init__(x, y, speed, maze, detection_radius, patrol_route)
        
        # Load original frames
        assets_path = os.path.join(os.path.dirname(__file__), "assets")
        self.original_frames = [
            pygame.image.load(os.path.join(assets_path, "spider", f"spider{i}.png")) for i in range(1, 5)
        ]
        
        # Sound effects
        sound_path = os.path.join(assets_path, "spider.ogg")
        self.spider_sound = pygame.mixer.Sound(sound_path)
        
        self.patrol_dir = 1  # 1 = down, -1 = up
        self.direction = "right"
        self.current_frame = 0.0
        self.animation_speed = 0.08  # Slow leg animation
        
        # Scale frames to default size
        self.scale_frames(self.width)

    def set_size(self, size):
        self.width = size
        self.height = size
        self.scale_frames(size)

    def scale_frames(self, size):
        self.frames = [pygame.transform.scale(f, (size, size)) for f in self.original_frames]

    def update_ai(self, hero, maze):
        super().update_ai(hero, maze)
        
        # Continuous animation if active
        if self.active:
            self.current_frame += self.animation_speed
            if self.current_frame >= len(self.frames):
                self.current_frame = 0.0

            # Determine direction from grid targets
            if self.target_col < self.col:
                self.direction = "left"
            elif self.target_col > self.col:
                self.direction = "right"

    def patrol(self, maze):
        # Try moving vertically
        next_row = self.row + self.patrol_dir
        if self.is_walkable(maze, next_row, self.col):
            self.target_row = next_row
            self.target_col = self.col
        else:
            # Reverse vertical direction
            self.patrol_dir *= -1
            next_row = self.row + self.patrol_dir
            if self.is_walkable(maze, next_row, self.col):
                self.target_row = next_row
                self.target_col = self.col
            else:
                # Spider is blocked vertically on both sides
                # Try to find any walkable horizontal neighbor to avoid getting stuck
                for dc in [-1, 1]:
                    if self.is_walkable(maze, self.row, self.col + dc):
                        self.target_row = self.row
                        self.target_col = self.col + dc
                        break

    def draw(self, screen, hero):
        if not self.active:
            circle_color = (60, 60, 60)
        elif hero.shield_active():
            circle_color = (150, 150, 150)
        elif self.ai_state == 'CHASE':
            circle_color = (255, 0, 0)
        elif self.ai_state == 'SEARCH':
            circle_color = (255, 255, 0)
        else:  # PATROL
            circle_color = (0, 255, 0)

        pygame.draw.circle(
            screen,
            circle_color,
            (int(self.x + self.width // 2), int(self.y + self.height // 2)),
            int(self.detection_radius),
            1
        )

        # Draw current frame
        frame = self.frames[int(self.current_frame)]
        
        # Flip if facing left
        if self.direction == "left":
            frame = pygame.transform.flip(frame, True, False)

        screen.blit(frame, (self.x, self.y))

    def attack(self):
        current = pygame.time.get_ticks()
        if current - self.attack_cooldown > 1000:
            print("SPIDER SCREECH!")
            self.spider_sound.play()
            self.attack_cooldown = current
            return True
        return False

    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)

    @property
    def image(self):
        frame = self.frames[int(self.current_frame)]
        if self.direction == "left":
            frame = pygame.transform.flip(frame, True, False)
        return frame
