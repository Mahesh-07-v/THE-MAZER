import pygame

class Maze:

    def __init__(self, level=1):
        self.layouts = {
            1: [
                "##############",
                "#S         ###",
                "# #######   ##",
                "#       #   ##",
                "# ### # # ####",
                "# #   # #    H",
                "##############"
            ],
            2: [
                "#############",
                "#S          #",
                "# ####### # #",
                "# #       # #",
                "# # ####### #",
                "#          H#",
                "#############"
            ],
            3: [
                "####################",
                "#S     #          ##",
                "#####  ##### ###  ##",
                "#      #     #    ##",
                "# ###### ### ### ###",
                "#        #       H##",
                "####################"
            ],
            4: [
                "####################",
                "#S                 #",
                "##### ####### ######",
                "#                  #",
                "###### ###### ######",
                "#                 H#",
                "####################"
            ],
            5: [
                "########################",
                "#S                     #",
                "######  #######  #######",
                "#                      #",
                "#######  ######  #######",
                "#                     H#",
                "########################"
            ],
            6: [
                "##########################",
                "#S                       #",
                "#######  ######  #########",
                "#                        #",
                "########  ######  ########",
                "#                       H#",
                "##########################"
            ],
            7: [
                "##########################",
                "#S   ###    ###     ### H#",
                "# #  ### #  ### #   ### # ",
                "# ##     ##     ###     ##",
                "# #####  #####  #####  ###",
                "#                        #",
                "##########################"
            ],
            8: [
                "##########################",
                "#S       ##            H##",
                "##  ###  #  ######  ######",
                "#     ##    ##          ##",
                "####  #####  ######  #####",
                "#                        #",
                "##########################"
            ],
            9: [
                "################################",
                "#S  ##    ##    ##     ##     ##",
                "#  #####  #####  #####  ###  ###",
                "#      ##      ##      ##     ##",
                "#####  #####  #####  #####  ####",
                "#                            H##",
                "################################"
            ],
            10: [
                "####################################",
                "#S                               ###",
                "####   #######################  ####",
                "#     #                     #    ###",
                "# ##  # ##################  ###  ###",
                "# ### #                 ###      ###",
                "# ##  ################# #######  ###",
                "#                             ## H##",
                "####################################"
            ]
        }
        
        # Verify all layouts are solvable on load
        for lvl, layout in self.layouts.items():
            if not self.is_solvable(layout):
                raise ValueError(f"Error: Level {lvl} layout is unsolvable!")
                
        self.set_level(level)

    def is_solvable(self, layout):
        # Find S and H
        start = None
        end = None
        rows = len(layout)
        cols = len(layout[0])
        for r in range(rows):
            for c in range(cols):
                if layout[r][c] == 'S':
                    start = (r, c)
                elif layout[r][c] == 'H':
                    end = (r, c)
        if not start or not end:
            return False
            
        queue = [start]
        visited = {start}
        while queue:
            curr = queue.pop(0)
            if curr == end:
                return True
            for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nr, nc = curr[0] + dr, curr[1] + dc
                if 0 <= nr < rows and 0 <= nc < cols:
                    if layout[nr][nc] != '#' and (nr, nc) not in visited:
                        visited.add((nr, nc))
                        queue.append((nr, nc))
        return False

    def set_level(self, level):
        layout = self.layouts.get(level, self.layouts[1])
        if not self.is_solvable(layout):
            raise ValueError(f"Error: Level {level} layout is unsolvable!")
        self.layout = layout

        # Grid dimensions
        rows = len(layout)
        cols = len(layout[0])

        # Max dimensions for maze drawing (screen is 800x600, HUD takes top 40px)
        max_w = 800
        max_h = 560

        # Calculate cell size dynamically to fit within boundary
        self.cell_size = min(max_w / cols, max_h / rows)

        # Calculate offsets to center the maze
        self.start_x = (max_w - cols * self.cell_size) / 2
        self.start_y = 40 + (max_h - rows * self.cell_size) / 2

        self.walls = []
        self.corridors = []

        # Parse character grid
        for r in range(rows):
            for c in range(cols):
                char = layout[r][c]
                x_coord = self.start_x + c * self.cell_size
                y_coord = self.start_y + r * self.cell_size

                if char == '#':
                    self.walls.append(pygame.Rect(x_coord, y_coord, self.cell_size, self.cell_size))
                elif char == 'S':
                    # Hero centered in the cell (Hero size is 30x30)
                    self.hero_start_x = x_coord + (self.cell_size - 30) / 2
                    self.hero_start_y = y_coord + (self.cell_size - 30) / 2
                elif char == 'H':
                    # Heroine centered in the cell (Heroine size is 30x30)
                    self.heroine_x = x_coord + (self.cell_size - 30) / 2
                    self.heroine_y = y_coord + (self.cell_size - 30) / 2
                elif char == ' ':
                    # Corridor spot for spawns
                    self.corridors.append((x_coord + (self.cell_size - 30) / 2, y_coord + (self.cell_size - 30) / 2))

    def draw(self, screen):
        for wall in self.walls:
            pygame.draw.rect(
                screen,
                (150, 150, 150),
                wall
            )
