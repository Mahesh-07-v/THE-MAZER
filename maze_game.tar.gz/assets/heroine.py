import pygame
import os

class Heroine:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.width = 30
        self.height = 30

        # Load original frames
        assets_path = os.path.join(os.path.dirname(__file__), "assets")
        self.original_frames = [
            pygame.image.load(os.path.join(assets_path, "heroine", f"heroine{i}.png")) for i in range(1, 3)
        ]
        
        self.current_frame = 0.0
        self.animation_speed = 0.05  # Slow breathing effect
        
        # Scale frames to default size
        self.scale_frames(self.width)

    def set_size(self, size):
        self.width = size
        self.height = size
        self.scale_frames(size)

    def scale_frames(self, size):
        self.frames = [pygame.transform.scale(f, (size, size)) for f in self.original_frames]

    def draw(self, screen):
        # Tick animation frame
        self.current_frame += self.animation_speed
        if self.current_frame >= len(self.frames):
            self.current_frame = 0.0

        # Draw current frame
        frame = self.frames[int(self.current_frame)]
        screen.blit(frame, (self.x, self.y))

    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)

    @property
    def image(self):
        return self.frames[int(self.current_frame)]
