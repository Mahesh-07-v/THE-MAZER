from heapq import heappush, heappop

class Node:
    def __init__(self, position, parent=None):
        self.position = position  # (row, col)
        self.parent = parent
        self.g = 0
        self.h = 0
        self.f = 0

    def __eq__(self, other):
        if not isinstance(other, Node):
            return False
        return self.position == other.position

    def __lt__(self, other):
        return self.f < other.f

def astar(maze_layout, start, end):
    # If start and end are the same, return path with start
    if start == end:
        return [start]

    rows = len(maze_layout)
    cols = len(maze_layout[0])

    # Check bounds
    if not (0 <= start[0] < rows and 0 <= start[1] < cols):
        return []
    if not (0 <= end[0] < rows and 0 <= end[1] < cols):
        return []

    open_list = []
    closed_set = set()

    start_node = Node(start)
    heappush(open_list, (0, start_node))
    open_dict = {start: start_node}

    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    while open_list:
        current_node = heappop(open_list)[1]
        current_pos = current_node.position

        # Remove from open_dict tracker if this is indeed the current tracking node
        if current_pos in open_dict and open_dict[current_pos] == current_node:
            del open_dict[current_pos]

        if current_pos == end:
            path = []
            curr = current_node
            while curr:
                path.append(curr.position)
                curr = curr.parent
            return path[::-1]

        closed_set.add(current_pos)

        for dr, dc in directions:
            nr = current_pos[0] + dr
            nc = current_pos[1] + dc

            # Bounds check
            if not (0 <= nr < rows and 0 <= nc < cols):
                continue

            # Wall check
            if maze_layout[nr][nc] == '#':
                continue

            neighbor_pos = (nr, nc)

            if neighbor_pos in closed_set:
                continue

            g_score = current_node.g + 1
            h_score = abs(nr - end[0]) + abs(nc - end[1])
            f_score = g_score + h_score

            # Check if already in open_list with a lower g score
            if neighbor_pos in open_dict:
                existing_node = open_dict[neighbor_pos]
                if g_score >= existing_node.g:
                    continue

            neighbor_node = Node(neighbor_pos, current_node)
            neighbor_node.g = g_score
            neighbor_node.h = h_score
            neighbor_node.f = f_score

            heappush(open_list, (f_score, neighbor_node))
            open_dict[neighbor_pos] = neighbor_node

    return []  # No path found
