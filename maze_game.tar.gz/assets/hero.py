import pygame
import os

WIDTH = 800
HEIGHT = 600

class Hero:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.width = 30
        self.height = 30
        self.speed = 4

        self.__shield_active = False
        self.__shield_start = 0
        self.spawn_protection = True
        self.spawn_time = pygame.time.get_ticks()

        # Load original frames
        assets_path = os.path.join(os.path.dirname(__file__), "assets")
        self.original_walk_frames = [
            pygame.image.load(os.path.join(assets_path, "hero", f"walk{i}.png")) for i in range(1, 5)
        ]
        self.original_idle_frames = [
            pygame.image.load(os.path.join(assets_path, "hero", f"idle{i}.png")) for i in range(1, 3)
        ]
        self.original_shield_frames = [
            pygame.image.load(os.path.join(assets_path, "shield", f"shield{i}.png")) for i in range(1, 5)
        ]

        # Animation states
        self.current_walk_frame = 0.0
        self.current_idle_frame = 0.0
        self.current_shield_frame = 0.0
        self.walk_speed = 0.28
        self.idle_speed = 0.05
        self.shield_speed = 0.15
        
        self.direction = "right"
        self.moving = False

        # Scale frames to default size
        self.scale_frames(self.width)

    def reset(self, x, y):
        self.x = x
        self.y = y
        self.__shield_active = False
        self.__shield_start = 0
        self.spawn_protection = True
        self.spawn_time = pygame.time.get_ticks()
        self.direction = "right"
        self.moving = False
        self.current_walk_frame = 0.0
        self.current_idle_frame = 0.0
        self.current_shield_frame = 0.0

    def set_size(self, size):
        self.width = size
        self.height = size
        self.scale_frames(size)

    def scale_frames(self, size):
        self.walk_frames = [pygame.transform.scale(f, (size, size)) for f in self.original_walk_frames]
        self.idle_frames = [pygame.transform.scale(f, (size, size)) for f in self.original_idle_frames]
        
        shield_size = int(size * 1.6)
        self.shield_frames = [pygame.transform.scale(f, (shield_size, shield_size)) for f in self.original_shield_frames]

    def move(self, maze):
        new_x = self.x
        new_y = self.y
        keys = pygame.key.get_pressed()

        self.moving = False

        if keys[pygame.K_a]:
            new_x -= self.speed
            self.direction = "left"
        if keys[pygame.K_d]:
            new_x += self.speed
            self.direction = "right"
        if keys[pygame.K_w]:
            new_y -= self.speed
        if keys[pygame.K_s]:
            new_y += self.speed

        new_x = max(0, new_x)
        new_y = max(0, new_y)
        new_x = min(WIDTH - self.width, new_x)
        new_y = min(HEIGHT - self.height, new_y)

        future_rect = pygame.Rect(new_x, new_y, self.width, self.height)
        collision = False

        for wall in maze.walls:
            if future_rect.colliderect(wall):
                collision = True
                break

        if not collision:
            if self.x != new_x or self.y != new_y:
                self.moving = True
            self.x = new_x
            self.y = new_y

        # Update animation frames
        self.update_animation()

    def update_animation(self):
        if self.moving:
            self.current_walk_frame += self.walk_speed
            if self.current_walk_frame >= len(self.walk_frames):
                self.current_walk_frame = 0.0
        else:
            self.current_walk_frame = 0.0

        self.current_idle_frame += self.idle_speed
        if self.current_idle_frame >= len(self.idle_frames):
            self.current_idle_frame = 0.0

        if self.spawn_protection or self.__shield_active:
            self.current_shield_frame += self.shield_speed
            if self.current_shield_frame >= len(self.shield_frames):
                self.current_shield_frame = 0.0

    def draw(self, screen):
        # Select the correct frame based on movement
        if self.moving:
            frame = self.walk_frames[int(self.current_walk_frame)]
        else:
            frame = self.idle_frames[int(self.current_idle_frame)]

        # Flip horizontally if moving left
        if self.direction == "left":
            frame = pygame.transform.flip(frame, True, False)

        screen.blit(frame, (self.x, self.y))

        # Render magical shield sprite
        if self.spawn_protection or self.shield_active():
            shield_frame = self.shield_frames[int(self.current_shield_frame)]
            shield_size = shield_frame.get_width()
            sx = self.x + self.width // 2 - shield_size // 2
            sy = self.y + self.height // 2 - shield_size // 2
            screen.blit(shield_frame, (sx, sy))

    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)

    @property
    def image(self):
        if self.moving:
            frame = self.walk_frames[int(self.current_walk_frame)]
        else:
            frame = self.idle_frames[int(self.current_idle_frame)]
        if self.direction == "left":
            frame = pygame.transform.flip(frame, True, False)
        return frame

    def activate_shield(self):
        self.__shield_active = True
        self.__shield_start = pygame.time.get_ticks()

    def shield_active(self):
        return self.__shield_active

    def update_shield(self):
        if self.__shield_active:
            current = pygame.time.get_ticks()
            if current - self.__shield_start > 5000:
                self.__shield_active = False

    def update_spawn_protection(self):
        if self.spawn_protection:
            current = pygame.time.get_ticks()
            if current - self.spawn_time > 5000:
                self.spawn_protection = False
