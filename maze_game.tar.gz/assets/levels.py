LEVELS = {
    1: {
        "hero": (1, 1),
        "heroine": (18, 6),
        "snakes": [
            (8, 3)
        ],
        "spiders": [
            (14, 5)
        ],
        "pills": [
            (4, 4)
        ]
    },
    2: {
        "hero": (1, 1),
        "heroine": (22, 7),
        "snakes": [
            (10, 4)
        ],
        "spiders": [
            (18, 6)
        ],
        "pills": [
            (7, 3)
        ]
    },
    3: {
        "hero": (1, 1),
        "heroine": (24, 7),
        "snakes": [
            (12, 4)
        ],
        "spiders": [
            (20, 6)
        ],
        "pills": [
            (9, 3)
        ]
    },
    4: {
        "hero": (1, 1),
        "heroine": (26, 8),
        "snakes": [
            (13, 4)
        ],
        "spiders": [
            (22, 7)
        ],
        "pills": [
            (8, 3)
        ]
    },
    5: {
        "hero": (1, 1),
        "heroine": (30, 8),
        "snakes": [
            (15, 5)
        ],
        "spiders": [
            (25, 7)
        ],
        "pills": [
            (7, 3),
            (14, 3)
        ]
    },
    6: {
        "hero": (1, 1),
        "heroine": (33, 9),
        "snakes": [
            (16, 5)
        ],
        "spiders": [
            (28, 8)
        ],
        "pills": [
            (10, 3)
        ]
    },
    7: {
        "hero": (1, 1),
        "heroine": (36, 9),
        "snakes": [
            (18, 5)
        ],
        "spiders": [
            (30, 8)
        ],
        "pills": [
            (12, 4)
        ]
    },
    8: {
        "hero": (1, 1),
        "heroine": (40, 10),
        "snakes": [
            (20, 6)
        ],
        "spiders": [
            (34, 8)
        ],
        "pills": [
            (13, 4)
        ]
    },
    9: {
        "hero": (1, 1),
        "heroine": (44, 10),
        "snakes": [
            (22, 6)
        ],
        "spiders": [
            (38, 9)
        ],
        "pills": [
            (14, 4)
        ]
    },
    10: {
        "hero": (1, 1),
        "heroine": (48, 10),
        "snakes": [
            (24, 6)
        ],
        "spiders": [
            (42, 9)
        ],
        "pills": []
    }
}

SNAKE_PATROLS = {
    1: [
        (7, 2),
        (7, 7),
        (12, 7),
        (12, 2)
    ],
    2: [
        (5, 2),
        (5, 10),
        (10, 10),
        (10, 2)
    ]
}

SPIDER_PATROLS = {}
