import pygame
import os
import math

def generate_all_sprites():
    # Setup directories
    base_dir = os.path.dirname(os.path.abspath(__file__))
    assets_dir = os.path.join(base_dir, "assets")
    
    dirs = {
        "hero": os.path.join(assets_dir, "hero"),
        "snake": os.path.join(assets_dir, "snake"),
        "spider": os.path.join(assets_dir, "spider"),
        "heroine": os.path.join(assets_dir, "heroine"),
        "shield": os.path.join(assets_dir, "shield")
    }
    
    for d in dirs.values():
        os.makedirs(d, exist_ok=True)
        
    pygame.init()
    
    # 1. Generate Hero Walk/Run Frames (4 frames)
    # Wears brown explorer hat, beige shirt, brown pants, dark brown boots
    # Dynamic contact and passing run cycle with vertical bobbing
    for i in range(4):
        surf = pygame.Surface((32, 32), pygame.SRCALPHA)
        
        if i == 0:
            # Contact: left leg forward, right leg back
            bob = 2
            legs_draw = lambda: (
                pygame.draw.rect(surf, (50, 30, 20), (7, 25 - bob, 5, 7)),  # Left boot forward
                pygame.draw.rect(surf, (50, 30, 20), (17, 25 - bob, 4, 4)) # Right boot back (bent)
            )
        elif i == 1:
            # Passing: body high, legs crossing
            bob = 0
            legs_draw = lambda: (
                pygame.draw.rect(surf, (50, 30, 20), (10, 25 - bob, 4, 7)), # Left leg down
                pygame.draw.rect(surf, (50, 30, 20), (16, 23 - bob, 4, 5)) # Right leg bending up
            )
        elif i == 2:
            # Contact: right leg forward, left leg back
            bob = 2
            legs_draw = lambda: (
                pygame.draw.rect(surf, (50, 30, 20), (9, 25 - bob, 4, 4)),  # Left boot back (bent)
                pygame.draw.rect(surf, (50, 30, 20), (18, 25 - bob, 5, 7)) # Right boot forward
            )
        elif i == 3:
            # Passing: body high, legs crossing
            bob = 0
            legs_draw = lambda: (
                pygame.draw.rect(surf, (50, 30, 20), (10, 23 - bob, 4, 5)), # Left leg bending up
                pygame.draw.rect(surf, (50, 30, 20), (16, 25 - bob, 4, 7)) # Right leg down
            )

        # Face (Skin tone)
        pygame.draw.rect(surf, (255, 224, 189), (11, 10 - bob, 10, 8))
        # Eyes (facing right)
        pygame.draw.rect(surf, (0, 0, 0), (16, 12 - bob, 2, 2))
        pygame.draw.rect(surf, (0, 0, 0), (20, 12 - bob, 2, 2))
        
        # Explorer Hat (Brown)
        pygame.draw.rect(surf, (139, 69, 19), (8, 6 - bob, 16, 4)) # brim
        pygame.draw.rect(surf, (100, 50, 15), (11, 2 - bob, 10, 4)) # top
        
        # Torso / Beige Shirt (stretched slightly during high phase)
        pygame.draw.rect(surf, (245, 245, 220), (10, 18 - bob, 12, 7 + bob))
        
        # Draw Legs
        legs_draw()
            
        pygame.image.save(surf, os.path.join(dirs["hero"], f"walk{i+1}.png"))
        
    # 2. Generate Hero Idle Frames (2 frames - subtle breathing bob)
    for i in range(2):
        surf = pygame.Surface((32, 32), pygame.SRCALPHA)
        bob = i  # bob down 1 pixel on frame 2
        
        # Face (Skin tone)
        pygame.draw.rect(surf, (255, 224, 189), (11, 10 - bob, 10, 8))
        # Eyes
        pygame.draw.rect(surf, (0, 0, 0), (16, 12 - bob, 2, 2))
        pygame.draw.rect(surf, (0, 0, 0), (20, 12 - bob, 2, 2))
        
        # Explorer Hat
        pygame.draw.rect(surf, (139, 69, 19), (8, 6 - bob, 16, 4))
        pygame.draw.rect(surf, (100, 50, 15), (11, 2 - bob, 10, 4))
        
        # Torso / Beige Shirt (slightly squashed when bobbed down)
        pygame.draw.rect(surf, (245, 245, 220), (10, 18 - bob, 12, 7 + bob))
        
        # Legs
        pygame.draw.rect(surf, (50, 30, 20), (11, 25, 4, 7))
        pygame.draw.rect(surf, (50, 30, 20), (17, 25, 4, 7))
        
        pygame.image.save(surf, os.path.join(dirs["hero"], f"idle{i+1}.png"))
        
    # 3. Generate Heroine Frames (2 frames - breathing Princess/Explorer)
    # Blonde hair, gold crown, pink dress
    for i in range(2):
        surf = pygame.Surface((32, 32), pygame.SRCALPHA)
        bob = i
        
        # Hair (behind face)
        pygame.draw.rect(surf, (255, 230, 100), (9, 9 - bob, 14, 12 + bob))
        
        # Face
        pygame.draw.rect(surf, (255, 224, 189), (11, 10 - bob, 10, 8))
        # Eyes
        pygame.draw.rect(surf, (0, 0, 0), (12, 12 - bob, 2, 2))
        pygame.draw.rect(surf, (0, 0, 0), (16, 12 - bob, 2, 2))
        
        # Gold Crown
        pygame.draw.polygon(surf, (255, 215, 0), [
            (11, 8 - bob), (13, 4 - bob), (15, 7 - bob), (17, 4 - bob), (19, 7 - bob), (21, 8 - bob)
        ])
        
        # Dress
        pygame.draw.rect(surf, (255, 105, 180), (11, 18 - bob, 10, 4 + bob))
        pygame.draw.polygon(surf, (255, 20, 147), [
            (11, 22 - bob), (6, 31), (25, 31), (20, 22 - bob)
        ])
        
        pygame.image.save(surf, os.path.join(dirs["heroine"], f"heroine{i+1}.png"))
        
    # 4. Generate Snake Frames (3 frames - moving green wave)
    for i in range(3):
        surf = pygame.Surface((32, 32), pygame.SRCALPHA)
        
        # Cobra Head (center at x=16, y=10)
        pygame.draw.rect(surf, (34, 139, 34), (12, 6, 8, 8), border_radius=2)
        # Red eyes
        pygame.draw.rect(surf, (255, 0, 0), (13, 8, 2, 2))
        pygame.draw.rect(surf, (255, 0, 0), (17, 8, 2, 2))
        
        # Flared hood
        pygame.draw.polygon(surf, (0, 100, 0), [(12, 9), (6, 14), (12, 16)])
        pygame.draw.polygon(surf, (0, 100, 0), [(20, 9), (26, 14), (20, 16)])
        
        # Slithering body (Sine wave shifting phase)
        phase = i * (2 * math.pi / 3)
        for y in range(16, 32):
            offset = 4 * math.sin((y - 16) * 0.4 - phase)
            x = 16 + int(offset)
            pygame.draw.circle(surf, (34, 139, 34), (x, y), 3)
            
        pygame.image.save(surf, os.path.join(dirs["snake"], f"snake{i+1}.png"))
        
    # 5. Generate Spider Frames (4 crawling frames)
    # Dark grey body, red eyes, alternating leg bends
    for i in range(4):
        surf = pygame.Surface((32, 32), pygame.SRCALPHA)
        
        # Abdomen and Cephalothorax
        pygame.draw.circle(surf, (40, 40, 40), (16, 16), 7)
        pygame.draw.circle(surf, (60, 60, 60), (16, 11), 4)
        
        # Red eyes
        pygame.draw.circle(surf, (255, 0, 0), (14, 9), 1)
        pygame.draw.circle(surf, (255, 0, 0), (18, 9), 1)
        
        # Crawling Legs
        for side in [-1, 1]:  # Left and Right
            for leg_i in range(4):
                # Anchor at body
                ax = 16 + side * 4
                ay = 11 + leg_i * 3
                
                # Alternate tip position
                phase = (leg_i + i) % 2
                leg_y_offset = -3 if phase == 0 else 3
                
                tx = 16 + side * 14
                ty = 11 + leg_i * 4 + leg_y_offset
                
                # Draw jointed leg
                mx = (ax + tx) // 2 + side * 2
                my = min(ay, ty) - 2
                pygame.draw.line(surf, (30, 30, 30), (ax, ay), (mx, my), 2)
                pygame.draw.line(surf, (30, 30, 30), (mx, my), (tx, ty), 2)
                
        pygame.image.save(surf, os.path.join(dirs["spider"], f"spider{i+1}.png"))
        
    # 6. Generate Shield Frames (4 rotating magic orb/particles frames)
    for i in range(4):
        surf = pygame.Surface((40, 40), pygame.SRCALPHA)
        
        # Yellow glowing circle
        pygame.draw.circle(surf, (255, 215, 0, 80), (20, 20), 18, 2)
        
        # Rotating sparkles (orbits around hero)
        num_particles = 6
        angle_offset = i * (2 * math.pi / 4)
        for p in range(num_particles):
            angle = angle_offset + p * (2 * math.pi / num_particles)
            px = 20 + int(14 * math.cos(angle))
            py = 20 + int(14 * math.sin(angle))
            pygame.draw.circle(surf, (255, 255, 120, 220), (px, py), 3)
            
        pygame.image.save(surf, os.path.join(dirs["shield"], f"shield{i+1}.png"))
        
    print("Successfully generated all retro sprite frames.")

if __name__ == "__main__":
    generate_all_sprites()
