print("START 1")
import asyncio
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from generate_sprites import generate_all_sprites
# Ensure all retro animated sprites exist before loading assets
generate_all_sprites()

import pygame
import random
import json
from hero import Hero
from heroine import Heroine
from maze import Maze
from snake import Snake
from spider import Spider
from securitypill import SecurityPill
from levels import LEVELS, SNAKE_PATROLS, SPIDER_PATROLS
print("START 2")

class LevelManager:
    def __init__(self):
        self.current_level = 1
        self.highest_level_unlocked = 10

    def load_progress(self):
        pass

    def save_progress(self):
        pass

    def unlock_next_level(self):
        pass

    def reset_all_progress(self):
        pass

pygame.init()

WIDTH = 800
HEIGHT = 600

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("The Mazer")

clock = pygame.time.Clock()

level_manager = LevelManager()
score_at_level_start = 0

# Initialize entities
hero = Hero(50, 50)
heroine = Heroine(700, 500)
maze = Maze()

# Load general sound effects
assets_dir = os.path.join(os.path.dirname(__file__), "assets")
pill_sound = pygame.mixer.Sound(os.path.join(assets_dir, "pill.ogg"))
win_sound = pygame.mixer.Sound(os.path.join(assets_dir, "win.ogg"))
lose_sound = pygame.mixer.Sound(os.path.join(assets_dir, "lose.ogg"))

# Load menu background and overlay
menu_bg = pygame.image.load(os.path.join(assets_dir, "menu_bg.png"))
menu_bg = pygame.transform.scale(menu_bg, (WIDTH, HEIGHT))
overlay = pygame.Surface((WIDTH, HEIGHT))
overlay.set_alpha(120)
overlay.fill((0, 0, 0))
print("START 3")

# Global state variables
state = 'START_MENU'
selected_menu_idx = 0
current_level = 1
score = 0
level_timer_start = 0
time_limit = 45000  # 45 seconds
trigger_col = 10
notifications = []

# Journey transition state variables
journey_start_time = 0
journey_hero_x = 100
journey_added_score = 0

# Monsters and pills lists
snakes = []
spiders = []
pills = []

# Rendering helpers for premium title text effects
def render_gradient_text(text, font, top_color, bottom_color):
    text_surf = font.render(text, True, (255, 255, 255))
    w, h = text_surf.get_size()
    grad_surf = pygame.Surface((w, h), pygame.SRCALPHA)
    for y in range(h):
        t = y / max(1, h - 1)
        r = int(top_color[0] + (bottom_color[0] - top_color[0]) * t)
        g = int(top_color[1] + (bottom_color[1] - top_color[1]) * t)
        b = int(top_color[2] + (bottom_color[2] - top_color[2]) * t)
        pygame.draw.line(grad_surf, (r, g, b), (0, y), (w, y))
    grad_surf.blit(text_surf, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    return grad_surf

def render_fancy_title(text, font, top_color, bottom_color, shadow_color, border_color, border_thickness, shadow_depth):
    main_text = render_gradient_text(text, font, top_color, bottom_color)
    mask_w, mask_h = main_text.get_size()
    white_mask = font.render(text, True, (255, 255, 255))
    
    pad = border_thickness + shadow_depth + 4
    combined_surf = pygame.Surface((mask_w + pad * 2, mask_h + pad * 2), pygame.SRCALPHA)
    
    def blit_mask(color, ox, oy):
        colored_mask = pygame.Surface((mask_w, mask_h), pygame.SRCALPHA)
        colored_mask.fill((color[0], color[1], color[2], 255))
        colored_mask.blit(white_mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        combined_surf.blit(colored_mask, (pad + ox, pad + oy))
        
    # Draw shadow depth (extrusion down and right)
    for d in range(1, shadow_depth + 1):
        for bx in range(-border_thickness, border_thickness + 1):
            for by in range(-border_thickness, border_thickness + 1):
                blit_mask(shadow_color, d + bx, d + by)
                
    # Draw border outline
    for bx in range(-border_thickness, border_thickness + 1):
        for by in range(-border_thickness, border_thickness + 1):
            if bx != 0 or by != 0:
                blit_mask(border_color, bx, by)
                
    combined_surf.blit(main_text, (pad, pad))
    return combined_surf

# Fonts
assets_dir = os.path.join(os.path.dirname(__file__), "assets")
title_font_path = os.path.join(assets_dir, "title_font.ttf")
if os.path.exists(title_font_path):
    font_title = pygame.font.Font(title_font_path, 110)
    font_menu = pygame.font.Font(title_font_path, 44)  # Use custom title font for menu items too!
else:
    font_title = pygame.font.Font(None, 110)
    font_menu = pygame.font.Font(None, 50)

font_large = pygame.font.Font(None, 72)
font_medium = pygame.font.Font(None, 36)
font_small = pygame.font.Font(None, 28)

# Pre-render the title for 60 FPS performance
pre_rendered_title = render_fancy_title(
    "THE MAZER",
    font_title,
    top_color=(255, 245, 200),    # Pale gold/white highlight
    bottom_color=(255, 140, 0),   # Deep orange-gold bottom
    shadow_color=(25, 5, 0),      # Dark brown shadow
    border_color=(230, 80, 0),    # Reddish-orange outline
    border_thickness=2,
    shadow_depth=6
)

def get_menu_rects():
    rects = []
    for i in range(3):
        item_w = 300
        item_h = 50
        rx = WIDTH // 2 - item_w // 2
        ry = 270 + i * 80 - item_h // 2
        rects.append(pygame.Rect(rx, ry, item_w, item_h))
    return rects

# Level names
level_names = {
    1: "Training Maze",
    2: "Forest Maze",
    3: "Underground Cave",
    4: "Ruined Temple",
    5: "Poison Garden",
    6: "Ancient Fortress",
    7: "Spider Nest",
    8: "Snake Kingdom",
    9: "Labyrinth of Shadows",
    10: "Heroine Prison"
}

# Story quotes during transitions
story_quotes = {
    1: "Heroine's voice echoes: 'Come closer...'",
    2: "Entering Level 3: Forest Maze...",
    3: "You find a map fragment pointing underground...",
    4: "Entering Level 5: Poison Garden...",
    5: "A ruined temple entrance appears in the distance...",
    6: "Entering Level 7: Spider Nest. Corridors get narrow...",
    7: "Escaping the nest into Level 8: Snake Kingdom...",
    8: "Entering Level 9: Labyrinth of Shadows...",
    9: "Almost there... Level 10: Heroine Prison lies ahead!"
}

def get_valid_grid_pos(maze, col, row):
    rows = len(maze.layout)
    cols = len(maze.layout[0])
    
    # 1. Check direct 0-indexed pos
    r = max(0, min(row, rows - 1))
    c = max(0, min(col, cols - 1))
    if maze.layout[r][c] != '#':
        return r, c
        
    # 2. Check 1-indexed pos (col-1, row-1)
    r2 = max(0, min(row - 1, rows - 1))
    c2 = max(0, min(col - 1, cols - 1))
    if maze.layout[r2][c2] != '#':
        return r2, c2
        
    # 3. Expanding circle search
    for dist in range(1, max(rows, cols)):
        for dr in range(-dist, dist + 1):
            for dc in range(-dist, dist + 1):
                if abs(dr) == dist or abs(dc) == dist:
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < rows and 0 <= nc < cols:
                        if maze.layout[nr][nc] != '#':
                            return nr, nc
                            
    # 4. Fallback to any corridor
    for tr in range(rows):
        for tc in range(cols):
            if maze.layout[tr][tc] != '#':
                return tr, tc
    return 1, 1

def start_level(level_num):
    global current_level, snakes, spiders, pills, level_timer_start, score_at_level_start, trigger_col, notifications
    current_level = level_num
    level_manager.current_level = level_num
    score_at_level_start = score
    maze.set_level(current_level)
    level_timer_start = pygame.time.get_ticks()
    notifications = []

    # Calculate trigger column dynamically
    cols = len(maze.layout[0])
    trigger_col = min(10, max(4, cols - 8))

    config = LEVELS.get(current_level)
    
    if config:
        # Calculate entity size dynamically based on cell_size
        entity_size = min(40, max(18, int(maze.cell_size * 0.82)))
        hero.set_size(entity_size)
        heroine.set_size(entity_size)

        # 1. Deterministic Hero Spawn
        hx_col, hy_row = config["hero"]
        h_row, h_col = get_valid_grid_pos(maze, hx_col, hy_row)
        hero_px = maze.start_x + h_col * maze.cell_size + (maze.cell_size - entity_size) / 2
        hero_py = maze.start_y + h_row * maze.cell_size + (maze.cell_size - entity_size) / 2
        hero.reset(hero_px, hero_py)

        # 2. Deterministic Heroine Spawn
        hex_col, hey_row = config["heroine"]
        he_row, he_col = get_valid_grid_pos(maze, hex_col, hey_row)
        heroine_px = maze.start_x + he_col * maze.cell_size + (maze.cell_size - entity_size) / 2
        heroine_py = maze.start_y + he_row * maze.cell_size + (maze.cell_size - entity_size) / 2
        heroine.x = heroine_px
        heroine.y = heroine_py

        # 3. Speeds and Detection Radius
        snake_speed = 4
        spider_speed = 3
        
        snake_radius = 150
        spider_radius = 220

        # 4. Deterministic Snakes with Custom Patrols
        snakes = []
        custom_snake_patrols = SNAKE_PATROLS.get(current_level, [])
        mapped_snake_patrol = [get_valid_grid_pos(maze, c, r) for c, r in custom_snake_patrols]
        
        for i, (scol, srow) in enumerate(config["snakes"]):
            sr, sc = get_valid_grid_pos(maze, scol, srow)
            sx = maze.start_x + sc * maze.cell_size + (maze.cell_size - entity_size) / 2
            sy = maze.start_y + sr * maze.cell_size + (maze.cell_size - entity_size) / 2
            snake_obj = Snake(sx, sy, snake_speed, maze, snake_radius, mapped_snake_patrol)
            snake_obj.set_size(entity_size)
            snakes.append(snake_obj)

        # 5. Deterministic Spiders with Custom Patrols
        spiders = []
        custom_spider_patrols = SPIDER_PATROLS.get(current_level, [])
        mapped_spider_patrol = [get_valid_grid_pos(maze, c, r) for c, r in custom_spider_patrols]
        
        for i, (scol, srow) in enumerate(config["spiders"]):
            sr, sc = get_valid_grid_pos(maze, scol, srow)
            sx = maze.start_x + sc * maze.cell_size + (maze.cell_size - entity_size) / 2
            sy = maze.start_y + sr * maze.cell_size + (maze.cell_size - entity_size) / 2
            spider_obj = Spider(sx, sy, spider_speed, maze, spider_radius, mapped_spider_patrol)
            spider_obj.set_size(entity_size)
            spiders.append(spider_obj)

        # 6. Deterministic Security Pills
        pills = []
        for pcol, prow in config["pills"]:
            pr, pc = get_valid_grid_pos(maze, pcol, prow)
            px = maze.start_x + pc * maze.cell_size + maze.cell_size / 2
            py = maze.start_y + pr * maze.cell_size + maze.cell_size / 2
            pills.append(SecurityPill(px, py))
    else:
        # Fallback
        hero.set_size(40)
        heroine.set_size(40)
        hero.reset(maze.hero_start_x, maze.hero_start_y)
        heroine.x = maze.heroine_x
        heroine.y = maze.heroine_y
        snakes = []
        spiders = []
        pills = []

def draw_button(screen, text, x, y, width, height, normal_color, hover_color, text_color, font, force_hover=False, fancy_text=False):
    mouse_pos = pygame.mouse.get_pos()
    rect = pygame.Rect(x, y, width, height)
    hovered = rect.collidepoint(mouse_pos) or force_hover
    
    if hovered:
        # Scale up slightly on hover and use gold border
        scale_padding = 4
        draw_rect = pygame.Rect(x - scale_padding, y - scale_padding, width + scale_padding * 2, height + scale_padding * 2)
        color = hover_color
        border_color = (255, 215, 0)  # Gold/Yellow glow
        border_width = 3
    else:
        draw_rect = rect
        color = normal_color
        border_color = (255, 255, 255)
        border_width = 2
        
    pygame.draw.rect(screen, color, draw_rect, border_radius=10)
    pygame.draw.rect(screen, border_color, draw_rect, border_width, border_radius=10)
    
    if fancy_text:
        # Render fancy gradient 3D text style like the title
        text_surf = render_fancy_title(
            text,
            font,
            top_color=(255, 245, 200),    # Pale gold/white highlight
            bottom_color=(255, 140, 0),   # Deep orange-gold bottom
            shadow_color=(25, 5, 0),      # Dark brown shadow
            border_color=(230, 80, 0),    # Reddish-orange outline
            border_thickness=1,
            shadow_depth=3
        )
    else:
        text_surf = font.render(text, True, text_color)
        
    text_w, text_h = text_surf.get_size()
    max_w = draw_rect.width - 20
    
    # Auto-resize text if it exceeds max allowed width
    if text_w > max_w:
        scale_factor = max_w / text_w
        new_w = int(text_w * scale_factor)
        new_h = int(text_h * scale_factor)
        text_surf = pygame.transform.smoothscale(text_surf, (new_w, new_h))
        
    text_rect = text_surf.get_rect(center=draw_rect.center)
    screen.blit(text_surf, text_rect)
    return rect.collidepoint(mouse_pos)

async def main():
    global running, state, selected_menu_idx, current_level, score, level_timer_start, time_limit, trigger_col, notifications, journey_start_time, journey_hero_x, journey_added_score, snakes, spiders, pills
    print("START 4")
    running = True
    
    while running:
        current_time = pygame.time.get_ticks()
        elapsed_time = current_time - level_timer_start
        remaining_time_ms = max(0, time_limit - elapsed_time)
        remaining_seconds = remaining_time_ms / 1000.0
    
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
    
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    mouse_pos = pygame.mouse.get_pos()
    
                    if state == 'START_MENU':
                        rects = get_menu_rects()
                        for i, rect in enumerate(rects):
                            if rect.collidepoint(mouse_pos):
                                selected_menu_idx = i
                                if i == 0:
                                    score = 0
                                    start_level(level_manager.highest_level_unlocked)
                                    state = 'PLAYING'
                                elif i == 1:
                                    state = 'LEVEL_SELECT'
                                elif i == 2:
                                    running = False
                                break
    
                    elif state == 'LEVEL_SELECT':
                        back_rect = pygame.Rect(300, 450, 200, 50)
                        if back_rect.collidepoint(mouse_pos):
                            state = 'START_MENU'
                        else:
                            button_size = 80
                            spacing_x = 25
                            spacing_y = 30
                            start_x = 150
                            start_y = 180
                            for i in range(1, 11):
                                row = (i - 1) // 5
                                col = (i - 1) % 5
                                bx = start_x + col * (button_size + spacing_x)
                                by = start_y + row * (button_size + spacing_y)
                                rect = pygame.Rect(bx, by, button_size, button_size)
                                if rect.collidepoint(mouse_pos) and i <= level_manager.highest_level_unlocked:
                                    score = 0
                                    start_level(i)
                                    state = 'PLAYING'
                                    break
    
                    elif state == 'GAME_OVER':
                        retry_rect = pygame.Rect(300, 350, 200, 50)
                        menu_rect = pygame.Rect(300, 420, 200, 50)
                        if retry_rect.collidepoint(mouse_pos):
                            score = score_at_level_start
                            start_level(current_level)
                            state = 'PLAYING'
                        elif menu_rect.collidepoint(mouse_pos):
                            score = 0
                            state = 'START_MENU'
    
                    elif state == 'GAME_WON':
                        play_again_rect = pygame.Rect(300, 330, 200, 50)
                        menu_rect = pygame.Rect(300, 400, 200, 50)
                        if play_again_rect.collidepoint(mouse_pos):
                            level_manager.reset_all_progress()
                            score = 0
                            start_level(1)
                            state = 'PLAYING'
                        elif menu_rect.collidepoint(mouse_pos):
                            score = 0
                            state = 'START_MENU'
    
                    elif state == 'JOURNEY':
                        continue_button_rect = pygame.Rect(300, 310, 200, 50)
                        if continue_button_rect.collidepoint(mouse_pos):
                            start_level(current_level + 1)
                            state = 'PLAYING'
    
            elif event.type == pygame.KEYDOWN:
                if state == 'START_MENU':
                    if event.key in (pygame.K_UP, pygame.K_w):
                        selected_menu_idx = (selected_menu_idx - 1) % 3
                    elif event.key in (pygame.K_DOWN, pygame.K_s):
                        selected_menu_idx = (selected_menu_idx + 1) % 3
                    elif event.key == pygame.K_RETURN:
                        if selected_menu_idx == 0:
                            score = 0
                            start_level(level_manager.highest_level_unlocked)
                            state = 'PLAYING'
                        elif selected_menu_idx == 1:
                            state = 'LEVEL_SELECT'
                        elif selected_menu_idx == 2:
                            running = False
                elif event.key == pygame.K_RETURN:
                    if state == 'JOURNEY':
                        start_level(current_level + 1)
                        state = 'PLAYING'
                elif event.key == pygame.K_r:
                    if state == 'GAME_OVER':
                        score = score_at_level_start
                        start_level(current_level)
                        state = 'PLAYING'
                    elif state == 'GAME_WON':
                        level_manager.reset_all_progress()
                        score = 0
                        start_level(1)
                        state = 'PLAYING'
                elif event.key == pygame.K_m:
                    if state == 'GAME_OVER' or state == 'GAME_WON':
                        score = 0
                        state = 'START_MENU'
                elif event.key == pygame.K_ESCAPE or event.key == pygame.K_BACKSPACE:
                    if state == 'LEVEL_SELECT':
                        state = 'START_MENU'
    
        # Timer check
        if state == 'PLAYING' and remaining_time_ms <= 0:
            state = 'GAME_OVER'
            lose_sound.play()
    
        screen.fill((30, 30, 30))
    
        if state == 'START_MENU':
            # Draw background and overlay
            screen.blit(menu_bg, (0, 0))
            screen.blit(overlay, (0, 0))
    
            # Title
            title_rect = pre_rendered_title.get_rect(center=(WIDTH // 2, 120))
            screen.blit(pre_rendered_title, title_rect)
    
            # Version
            version_surf = font_small.render("Version 1.0", True, (0, 0, 0))
            version_rect = version_surf.get_rect(center=(WIDTH // 2, 550))
            screen.blit(version_surf, version_rect)
    
            # Menu options list
            play_label = "Continue"
            if level_manager.highest_level_unlocked > 1:
                play_label = f"Continue (Lvl {level_manager.highest_level_unlocked})"
            else:
                play_label = "Play"
    
            menu_items = [play_label, "Level Select", "Quit"]
            rects = get_menu_rects()
            mouse_pos = pygame.mouse.get_pos()
    
            colors = [
                ((50, 150, 50), (80, 190, 80)),    # Green (normal, hover)
                ((50, 100, 200), (80, 130, 255)),  # Blue (normal, hover)
                ((150, 50, 50), (200, 80, 80))     # Red (normal, hover)
            ]
    
            # Update selected index based on mouse hover
            for i, rect in enumerate(rects):
                if rect.collidepoint(mouse_pos):
                    selected_menu_idx = i
    
            for i, item in enumerate(menu_items):
                is_selected = (i == selected_menu_idx)
                display_text = f"▶ {item}" if is_selected else f"{item}"
                normal_c, hover_c = colors[i]
                
                draw_button(
                    screen, 
                    display_text, 
                    rects[i].x, 
                    rects[i].y, 
                    rects[i].width, 
                    rects[i].height, 
                    normal_c, 
                    hover_c, 
                    (255, 255, 255), 
                    font_menu, 
                    force_hover=is_selected,
                    fancy_text=True
                )
    
            # Instructions
            inst_surf = font_small.render("Move: WASD / Arrows | Select: ENTER / Mouse Click", True, (0, 0, 0))
            inst_rect = inst_surf.get_rect(center=(WIDTH // 2, 500))
            screen.blit(inst_surf, inst_rect)
    
        elif state == 'LEVEL_SELECT':
            title_surf = font_large.render("LEVEL SELECT", True, (0, 255, 255))
            title_rect = title_surf.get_rect(center=(WIDTH // 2, 80))
            screen.blit(title_surf, title_rect)
    
            button_size = 80
            spacing_x = 25
            spacing_y = 30
            start_x = 150
            start_y = 180
    
            mouse_pos = pygame.mouse.get_pos()
    
            for i in range(1, 11):
                row = (i - 1) // 5
                col = (i - 1) % 5
                bx = start_x + col * (button_size + spacing_x)
                by = start_y + row * (button_size + spacing_y)
    
                rect = pygame.Rect(bx, by, button_size, button_size)
                unlocked = i <= level_manager.highest_level_unlocked
    
                if unlocked:
                    hovered = rect.collidepoint(mouse_pos)
                    bg_color = (0, 180, 100) if hovered else (0, 120, 70)
                    text_color = (255, 255, 255)
                    pygame.draw.rect(screen, bg_color, rect, border_radius=8)
                    pygame.draw.rect(screen, (255, 255, 255), rect, 2, border_radius=8)
    
                    level_text = f"{i}"
                    if i < level_manager.highest_level_unlocked:
                        level_text += " ✓"
    
                    text_surf = font_medium.render(level_text, True, text_color)
                    text_rect = text_surf.get_rect(center=rect.center)
                    screen.blit(text_surf, text_rect)
                else:
                    bg_color = (50, 50, 50)
                    pygame.draw.rect(screen, bg_color, rect, border_radius=8)
                    pygame.draw.rect(screen, (100, 100, 100), rect, 1, border_radius=8)
    
                    lock_surf = font_small.render("🔒", True, (150, 150, 150))
                    lock_rect = lock_surf.get_rect(center=rect.center)
                    screen.blit(lock_surf, lock_rect)
    
            draw_button(screen, "BACK", 300, 450, 200, 50, (100, 100, 100), (150, 150, 150), (255, 255, 255), font_medium)
    
        elif state == 'PLAYING':
            maze.draw(screen)
            hero.draw(screen)
            heroine.draw(screen)
    
            for snake in snakes:
                snake.draw(screen, hero)
            for spider in spiders:
                spider.draw(screen, hero)
    
            for pill in pills:
                pill.draw(screen)
    
            # Draw active notifications
            now = pygame.time.get_ticks()
            notifications = [n for n in notifications if n["expire"] > now]
            for idx, n in enumerate(notifications):
                text_surf = font_medium.render(n["text"], True, (255, 69, 0))
                text_rect = text_surf.get_rect(center=(WIDTH // 2, 80 + idx * 30))
                screen.blit(text_surf, text_rect)
    
            hud_bar = pygame.Surface((WIDTH, 40))
            hud_bar.fill((10, 10, 10))
            hud_bar.set_alpha(180)
            screen.blit(hud_bar, (0, 0))
    
            hud_level = font_small.render(f"LEVEL: {current_level}/10 - {level_names.get(current_level, '')}", True, (255, 255, 255))
            hud_score = font_small.render(f"SCORE: {score}", True, (255, 255, 255))
            hud_timer = font_small.render(f"TIME: {remaining_seconds:.1f}s", True, (255, 255, 0) if remaining_seconds > 10 else (255, 0, 0))
    
            screen.blit(hud_level, (20, 8))
            screen.blit(hud_score, (360, 8))
            screen.blit(hud_timer, (WIDTH - 150, 8))
    
            hero.move(maze)
            hero.update_shield()
            hero.update_spawn_protection()
    
            # Calculate hero's current column
            hero_col = int(((hero.x + 15) - maze.start_x) // maze.cell_size)
    
            for snake in snakes:
                if not snake.active and hero_col > trigger_col:
                    snake.active = True
                    snake.hiss_sound.play()
                    notifications.append({"text": "You hear a hiss...", "expire": pygame.time.get_ticks() + 2000})
                if snake.active:
                    snake.update_ai(hero, maze)
    
            for spider in spiders:
                if not spider.active and hero_col > trigger_col:
                    spider.active = True
                    spider.spider_sound.play()
                    notifications.append({"text": "You hear a screech...", "expire": pygame.time.get_ticks() + 2000})
                if spider.active:
                    spider.update_ai(hero, maze)
    
            for pill in pills:
                if pill.active:
                    pill_rect = pygame.Rect(pill.x - 10, pill.y - 10, 20, 20)
                    if hero.get_rect().colliderect(pill_rect):
                        hero.activate_shield()
                        pill.active = False
                        pill_sound.play()
    
            if hero.get_rect().colliderect(heroine.get_rect()):
                level_points = 1000 + int(remaining_seconds * 50)
                score += level_points
                win_sound.play()
    
                level_manager.unlock_next_level()
    
                if current_level < 10:
                    state = 'JOURNEY'
                    journey_start_time = pygame.time.get_ticks()
                    journey_hero_x = 100
                    journey_added_score = level_points
                else:
                    state = 'GAME_WON'
    
            if not hero.shield_active() and not hero.spawn_protection:
                for snake in snakes:
                    if snake.active and hero.get_rect().colliderect(snake.get_rect()):
                        if snake.attack():
                            state = 'GAME_OVER'
                            lose_sound.play()
                for spider in spiders:
                    if spider.active and hero.get_rect().colliderect(spider.get_rect()):
                        if spider.attack():
                            state = 'GAME_OVER'
                            lose_sound.play()
    
        elif state == 'JOURNEY':
            elapsed = min(current_time - journey_start_time, 5000)
    
            comp_text = font_large.render(f"LEVEL {current_level} COMPLETE", True, (100, 255, 100))
            comp_rect = comp_text.get_rect(center=(WIDTH // 2, 120))
            screen.blit(comp_text, comp_rect)
    
            bonus_text = font_medium.render(f"+{journey_added_score} SCORE", True, (255, 215, 0))
            bonus_rect = bonus_text.get_rect(center=(WIDTH // 2, 190))
            screen.blit(bonus_text, bonus_rect)
    
            story_str = story_quotes.get(current_level, "Journeying forward...")
            story_text = font_medium.render(story_str, True, (255, 255, 255))
            story_rect = story_text.get_rect(center=(WIDTH // 2, 260))
            screen.blit(story_text, story_rect)
    
            draw_button(screen, "CONTINUE", 300, 310, 200, 50, (50, 150, 255), (80, 180, 255), (255, 255, 255), font_medium)
    
            pygame.draw.line(screen, (100, 100, 100), (50, 420), (750, 420), 4)
    
            journey_hero_x = 100 + (elapsed / 5000.0) * 550
            journey_hero_x = min(journey_hero_x, 650)
    
            screen.blit(hero.image, (int(journey_hero_x), 380))
            screen.blit(heroine.image, (650, 380))
    
            next_lvl_text = font_small.render("Press ENTER to Continue", True, (150, 150, 150))
            next_lvl_rect = next_lvl_text.get_rect(center=(WIDTH // 2, 480))
            screen.blit(next_lvl_text, next_lvl_rect)
    
        elif state == 'GAME_OVER':
            go_surf = font_large.render("GAME OVER", True, (255, 50, 50))
            go_rect = go_surf.get_rect(center=(WIDTH // 2, 150))
            screen.blit(go_surf, go_rect)
    
            lvl_surf = font_medium.render(f"Level Failed: {current_level}/10 - {level_names.get(current_level, '')}", True, (200, 200, 200))
            lvl_rect = lvl_surf.get_rect(center=(WIDTH // 2, 210))
            screen.blit(lvl_surf, lvl_rect)
    
            scr_surf = font_medium.render(f"Score: {score}", True, (200, 200, 200))
            scr_rect = scr_surf.get_rect(center=(WIDTH // 2, 270))
            screen.blit(scr_surf, scr_rect)
    
            draw_button(screen, "RETRY LEVEL", 300, 330, 200, 50, (50, 150, 50), (80, 190, 80), (255, 255, 255), font_medium)
    
            draw_button(screen, "MAIN MENU", 300, 400, 200, 50, (100, 100, 100), (150, 150, 150), (255, 255, 255), font_medium)
    
            key_hint = font_small.render("Press R to retry, M for Main Menu", True, (120, 120, 120))
            key_hint_rect = key_hint.get_rect(center=(WIDTH // 2, 480))
            screen.blit(key_hint, key_hint_rect)
    
        elif state == 'GAME_WON':
            gw_surf = font_large.render("VICTORY!", True, (255, 215, 0))
            gw_rect = gw_surf.get_rect(center=(WIDTH // 2, 150))
            screen.blit(gw_surf, gw_rect)
    
            sub_surf = font_medium.render("You successfully saved the heroine from Prison!", True, (100, 255, 100))
            sub_rect = sub_surf.get_rect(center=(WIDTH // 2, 210))
            screen.blit(sub_surf, sub_rect)
    
            scr_surf = font_medium.render(f"Final Score: {score}", True, (255, 255, 255))
            scr_rect = scr_surf.get_rect(center=(WIDTH // 2, 270))
            screen.blit(scr_surf, scr_rect)
    
            draw_button(screen, "PLAY AGAIN", 300, 330, 200, 50, (50, 180, 100), (80, 220, 130), (255, 255, 255), font_medium)
    
            draw_button(screen, "MAIN MENU", 300, 400, 200, 50, (100, 100, 100), (150, 150, 150), (255, 255, 255), font_medium)
    
            key_hint = font_small.render("Press R to play again, M for Main Menu", True, (120, 120, 120))
            key_hint_rect = key_hint.get_rect(center=(WIDTH // 2, 480))
            screen.blit(key_hint, key_hint_rect)
    
        pygame.display.update()
        clock.tick(60)
        await asyncio.sleep(0)
    
    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())
