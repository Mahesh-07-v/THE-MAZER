import pygame

class Monster:

    def __init__(self, x, y, speed, maze, detection_radius=130, patrol_route=None):
        self.width = 30
        self.height = 30
        self.speed = speed
        self.detection_radius = detection_radius
        self.patrol_route = patrol_route if patrol_route else []
        self.active = False
        self.patrol_index = 0

        # Calculate initial grid position from passed pixel coordinates
        self.row, self.col = self.pixel_to_grid(x, y, maze)

        # Snap initial position to exactly the center of the spawning cell
        self.x, self.y = self.grid_to_pixel(self.row, self.col, maze)

        self.target_row = self.row
        self.target_col = self.col

        self.attack_cooldown = 0
        self.ai_state = 'PATROL'
        self.last_known_pos = None
        self.search_start_time = 0

        # A* Pathfinding variables
        self.path = []
        self.last_path_update = 0

    def get_rect(self):
        return pygame.Rect(
            self.x,
            self.y,
            self.width,
            self.height
        )

    def patrol(self, maze):
        # To be overridden by subclasses (Snake, Spider)
        pass

    def pixel_to_grid(self, x, y, maze):
        # Center of entity is at (x + width // 2, y + height // 2)
        cx = x + self.width // 2
        cy = y + self.height // 2
        col = int((cx - maze.start_x) // maze.cell_size)
        row = int((cy - maze.start_y) // maze.cell_size)
        rows = len(maze.layout)
        cols = len(maze.layout[0])
        # Clamp to grid bounds
        col = max(0, min(col, cols - 1))
        row = max(0, min(row, rows - 1))
        return row, col

    def grid_to_pixel(self, row, col, maze):
        # Convert back to centered top-left coordinates for a dynamic-sized entity
        x = maze.start_x + col * maze.cell_size + (maze.cell_size - self.width) / 2
        y = maze.start_y + row * maze.cell_size + (maze.cell_size - self.height) / 2
        return x, y

    def set_size(self, size):
        self.width = size
        self.height = size
        self.image = pygame.transform.scale(self.original_image, (size, size))

    def is_walkable(self, maze, r, c):
        rows = len(maze.layout)
        cols = len(maze.layout[0])
        if 0 <= r < rows and 0 <= c < cols:
            return maze.layout[r][c] != '#'
        return False

    def move_towards_target_cell(self, maze):
        tx, ty = self.grid_to_pixel(self.target_row, self.target_col, maze)
        dx = tx - self.x
        dy = ty - self.y
        distance = (dx**2 + dy**2)**0.5
        if distance > 0:
            if distance <= self.speed:
                self.x = tx
                self.y = ty
                self.row = self.target_row
                self.col = self.target_col
            else:
                self.x += self.speed * dx / distance
                self.y += self.speed * dy / distance
        else:
            self.row = self.target_row
            self.col = self.target_col

    def update_ai(self, hero, maze):
        current_time = pygame.time.get_ticks()

        # Calculate distance to Hero
        dx = hero.x - self.x
        dy = hero.y - self.y
        distance = (dx**2 + dy**2)**0.5

        # Check if hero is within detection radius and not shielded or spawn protected
        hero_detected = (distance < self.detection_radius) and not hero.shield_active() and not hero.spawn_protection

        # 1. State machine transition logic (immediate detection)
        if hero_detected:
            if self.ai_state != 'CHASE':
                self.ai_state = 'CHASE'
                # Immediately calculate path
                hero_row, hero_col = self.pixel_to_grid(hero.x, hero.y, maze)
                from astar import astar
                self.path = astar(maze.layout, (self.row, self.col), (hero_row, hero_col))
                self.last_path_update = current_time
                if len(self.path) > 1:
                    # Pop the current position node
                    self.path.pop(0)
                    self.target_row, self.target_col = self.path[0]
                else:
                    # If start and end are different and no path found
                    if (self.row, self.col) != (hero_row, hero_col):
                        self.ai_state = 'RECALCULATE'
        else:
            if self.ai_state == 'CHASE':
                self.ai_state = 'SEARCH'
                self.last_known_pos = (hero.x, hero.y)
                self.search_start_time = current_time
                # Immediately calculate path to search position
                search_row, search_col = self.pixel_to_grid(self.last_known_pos[0], self.last_known_pos[1], maze)
                from astar import astar
                self.path = astar(maze.layout, (self.row, self.col), (search_row, search_col))
                self.last_path_update = current_time
                if len(self.path) > 1:
                    self.path.pop(0)
                    self.target_row, self.target_col = self.path[0]
            elif self.ai_state == 'SEARCH':
                if current_time - self.search_start_time > 3000:
                    self.ai_state = 'PATROL'
                    self.path = []

        # 2. Movement/transition logic
        # If currently in transit (meaning we haven't reached target cell center yet)
        if self.row != self.target_row or self.col != self.target_col:
            self.move_towards_target_cell(maze)
        else:
            # We are exactly at the current cell center, decide next target cell
            if self.ai_state == 'CHASE':
                # Recalculate path periodically if 500ms passed
                if current_time - self.last_path_update > 500 or not self.path or len(self.path) <= 1:
                    hero_row, hero_col = self.pixel_to_grid(hero.x, hero.y, maze)
                    from astar import astar
                    self.path = astar(maze.layout, (self.row, self.col), (hero_row, hero_col))
                    self.last_path_update = current_time

                if len(self.path) > 1:
                    self.path.pop(0)
                    self.target_row, self.target_col = self.path[0]
                else:
                    hero_row, hero_col = self.pixel_to_grid(hero.x, hero.y, maze)
                    if (self.row, self.col) != (hero_row, hero_col):
                        self.ai_state = 'RECALCULATE'

            elif self.ai_state == 'RECALCULATE':
                # Try to recalculate path immediately
                hero_row, hero_col = self.pixel_to_grid(hero.x, hero.y, maze)
                from astar import astar
                self.path = astar(maze.layout, (self.row, self.col), (hero_row, hero_col))
                self.last_path_update = current_time

                if len(self.path) > 1:
                    self.ai_state = 'CHASE'
                    self.path.pop(0)
                    self.target_row, self.target_col = self.path[0]
                else:
                    # Cannot find path, go back to PATROL and select next patrol cell
                    self.ai_state = 'PATROL'
                    self.path = []
                    self.patrol(maze)

            elif self.ai_state == 'SEARCH':
                if len(self.path) > 1:
                    self.path.pop(0)
                    self.target_row, self.target_col = self.path[0]
                # If path is empty, we just wait at the current cell (search state is timed)

            elif self.ai_state == 'PATROL':
                if self.patrol_route:
                    waypoint = self.patrol_route[self.patrol_index]
                    # If reached current waypoint, advance to next
                    if (self.row, self.col) == waypoint:
                        self.patrol_index = (self.patrol_index + 1) % len(self.patrol_route)
                        waypoint = self.patrol_route[self.patrol_index]
                        from astar import astar
                        self.path = astar(maze.layout, (self.row, self.col), waypoint)

                    # If no active path, calculate path to current waypoint
                    if not self.path or len(self.path) <= 1:
                        from astar import astar
                        self.path = astar(maze.layout, (self.row, self.col), waypoint)

                    if len(self.path) > 1:
                        self.path.pop(0)
                        self.target_row, self.target_col = self.path[0]
                else:
                    self.patrol(maze)

            # After setting a new target cell, start moving towards it in the same frame
            if self.row != self.target_row or self.col != self.target_col:
                self.move_towards_target_cell(maze)
