import pygame
import os

class SecurityPill:

    def __init__(self, x, y):

        self.x = x
        self.y = y

        self.radius = 10

        self.active = True

        image_path = os.path.join(os.path.dirname(__file__), "assets", "pill.png")
        self.image = pygame.image.load(image_path)
        self.image = pygame.transform.scale(self.image, (20, 20))


    def draw(self, screen):

        if self.active:

            screen.blit(
                self.image,
                (self.x - 10, self.y - 10)
            )
